'use client';

import { useState } from 'react';
import { useLanguage } from '@/components/LanguageContext';

interface Member {
  roleEn: string;
  roleMn: string;
  name: string;
  bioEn: string;
  bioMn: string;
}

interface Department {
  key: string;
  titleEn: string;
  titleMn: string;
  members: Member[];
}

const DEPARTMENTS: Department[] = [
  {
    key: 'leadership',
    titleEn: 'Leadership',
    titleMn: 'Удирдлага',
    members: [
      {
        roleEn: 'Organizer',
        roleMn: 'Зохион байгуулагч',
        name: 'Munkhtushig',
        bioEn: 'Directing strategic operations, licensing compliance, and overarching vision for the event.',
        bioMn: 'Арга хэмжээний стратеги, франчайз зөвшөөрөл болон ерөнхий чиглэлийг удирдан чиглүүлэгч.',
      },
      {
        roleEn: 'Co-Organizer',
        roleMn: 'Хамтран зохион байгуулагч',
        name: 'Munkherdene',
        bioEn: 'Coordinating department workflows, operational planning, and venue execution.',
        bioMn: 'Албадын үйл ажиллагаа, операци төлөвлөлт болон талбайн зохион байгуулалтыг зохицуулагч.',
      },
    ],
  },
  {
    key: 'curation',
    titleEn: 'Curation',
    titleMn: 'Куратор',
    members: [
      {
        roleEn: 'Curation Lead',
        roleMn: 'Куратор багийн гишүүн',
        name: 'Anar',
        bioEn: 'Leading speaker discovery, talk shaping, and editorial coaching for the stage.',
        bioMn: 'Илтгэгчдийг сонгон шалгаруулах, илтгэл бэлтгэх болон зөвлөн чиглүүлэх баг.',
      },
      {
        roleEn: '?',
        roleMn: '?',
        name: '?',
        bioEn: 'Team member to be revealed soon.',
        bioMn: 'Багийн гишүүн удахгүй зарлагдана.',
      },
    ],
  },
  {
    key: 'media-design',
    titleEn: 'Media & Design',
    titleMn: 'Медиа ба Дизайн',
    members: [
      {
        roleEn: 'Designer',
        roleMn: 'Дизайнер',
        name: 'Munkhjin',
        bioEn: 'Directing visual branding, digital media assets, stage production aesthetics, and creative direction.',
        bioMn: 'Арга хэмжээний визуал брэнд, дижитал контент, тайзны дизайн болон бүтээлч чиглэлийг хариуцагч.',
      },
      {
        roleEn: '?',
        roleMn: '?',
        name: '?',
        bioEn: 'Team member to be revealed soon.',
        bioMn: 'Багийн гишүүн удахгүй зарлагдана.',
      },
    ],
  },
  {
    key: 'logistics',
    titleEn: 'Logistics',
    titleMn: 'Логистик',
    members: [
      {
        roleEn: '?',
        roleMn: '?',
        name: '?',
        bioEn: 'Team member to be revealed soon.',
        bioMn: 'Багийн гишүүн удахгүй зарлагдана.',
      },
      {
        roleEn: '?',
        roleMn: '?',
        name: '?',
        bioEn: 'Team member to be revealed soon.',
        bioMn: 'Багийн гишүүн удахгүй зарлагдана.',
      },
    ],
  },
];

const FILTERS: { key: string; en: string; mn: string }[] = [
  { key: 'all', en: 'All Departments', mn: 'Бүх алба' },
  { key: 'leadership', en: 'Leadership', mn: 'Удирдлага' },
  { key: 'curation', en: 'Curation', mn: 'Куратор' },
  { key: 'media-design', en: 'Media & Design', mn: 'Медиа ба Дизайн' },
  { key: 'logistics', en: 'Logistics', mn: 'Логистик' },
];

export default function TeamPage() {
  const { t } = useLanguage();
  const [activeFilter, setActiveFilter] = useState('all');

  const visibleDepartments = DEPARTMENTS.filter((d) => activeFilter === 'all' || d.key === activeFilter);

  return (
    <>
      {/* HERO */}
      <section className="team-hero">
        <div className="wrap">
          <div className="hero-badge">{t('Behind The Stage', 'Тайзны ард')}</div>
          <h1>{t('Meet The Visionaries', 'Зохион байгуулах баг')}</h1>
          <p>{t('The dedicated team working behind the scenes to make this event happen.', 'Энэхүү эвэнтэд зориулан тайзны ард ажиллаж буй манай баг хамт олон.')}</p>

          <div className="team-stats-grid">
            <div className="stat-item">
              <div className="stat-num">?</div>
              <div className="stat-label">{t('Total Members', 'Нийт гишүүд')}</div>
            </div>
            <div className="stat-item">
              <div className="stat-num">04</div>
              <div className="stat-label">{t('Departments', 'Албадууд')}</div>
            </div>
            <div className="stat-item">
              <div className="stat-num">100%</div>
              <div className="stat-label">{t('Volunteer Driven', 'Сайн дурын баг')}</div>
            </div>
            <div className="stat-item">
              <div className="stat-num">2026</div>
              <div className="stat-label">{t('Edition Team', '2026 оны баг')}</div>
            </div>
          </div>
        </div>
      </section>

      {/* STICKY FILTER BAR */}
      <div className="filter-wrapper">
        <div className="wrap">
          <div className="filter-pills">
            {FILTERS.map((f) => (
              <button
                key={f.key}
                className={`filter-btn${activeFilter === f.key ? ' active' : ''}`}
                onClick={() => setActiveFilter(f.key)}
              >
                {t(f.en, f.mn)}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* TEAM CONTENT */}
      <main className="wrap">
        {visibleDepartments.map((dept) => (
          <section className="dept-section" key={dept.key}>
            <div className="dept-header">
              <h2 className="dept-title">{t(dept.titleEn, dept.titleMn)}</h2>
              <div className="dept-divider"></div>
              <span className="dept-count">
                <span>{t('? Members', '? Гишүүн')}</span>
              </span>
            </div>

            <div className="team-grid">
              {dept.members.map((m, idx) => (
                <div className="member-card" key={idx}>
                  <div className="member-image-wrapper">
                    <div className="mystery-symbol">?</div>
                  </div>
                  <div className="member-info">
                    <div className="member-role">{t(m.roleEn, m.roleMn)}</div>
                    <h3 className="member-name">{m.name}</h3>
                    <p className="member-bio">{t(m.bioEn, m.bioMn)}</p>
                  </div>
                </div>
              ))}
            </div>
          </section>
        ))}
      </main>
    </>
  );
}
