'use client';

import { useLanguage } from '@/components/LanguageContext';
import { useReveal } from '@/components/useReveal';

export default function ApplyPage() {
  const { t } = useLanguage();
  const reveal = useReveal<HTMLDivElement>();

  return (
    <main className="wrap" style={{ paddingTop: 120, minHeight: '80vh' }}>
      <div ref={reveal.ref} className={reveal.className}>
        <h1 className="section-title" style={{ marginBottom: 8 }}>
          {t('Applications & Recruitment', 'Илтгэгч ба Багийн бүртгэл')}
        </h1>
        <p style={{ color: 'var(--text-muted)', marginBottom: 24 }}>
          {t(
            'Choose an application below to apply as a speaker or join the organizing team for 2026.',
            '2026 оны TEDx арга хэмжээнд илтгэгчээр оролцох эсвэл зохион байгуулах багт нэгдэх анкет.'
          )}
        </p>

        <div className="apply-grid">
          {/* Speaker Recruitment Card */}
          <div className="apply-card">
            <div>
              <span className="apply-badge">{t('Stage Call', 'Илтгэгчийн урилга')}</span>
              <h2 className="apply-title">{t('Speaker Application', 'Илтгэгчийн анкет')}</h2>
              <p className="apply-desc">
                {t(
                  'Have an idea worth spreading? We are looking for student leaders, educators, and visionaries to share ideas live on stage.',
                  'Та залууст хүргэх үнэ цэнэтэй санаатай юу? Тайзан дээр илтгэл тавих сурагчид, багш нар болон зочдыг урьж байна.'
                )}
              </p>
            </div>
            <a
              href="https://docs.google.com/forms/d/e/1FAIpQLSeDVXkHyLZ36OvnBQ0OesNOzop77LhwibkIZZxv4QJeupXg6w/viewform?usp=header"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-primary"
              style={{ textAlign: 'center', textDecoration: 'none' }}
            >
              {t('Apply as Speaker', 'Илтгэгчээр бүртгүүлэх')}
            </a>
          </div>

          {/* Team Recruitment Card */}
          <div className="apply-card">
            <div>
              <span className="apply-badge">{t('Organizing Core', 'Зохион байгуулах баг')}</span>
              <h2 className="apply-title">{t('Team Recruitment', 'Багийн гишүүний анкет')}</h2>
              <p className="apply-desc">
                {t(
                  'Join our student team across Media & Design, Stage & Technical, and Logistics departments to bring TEDx to life.',
                  'Медиа, Дизайн, Техник болон Ложистикийн багт нэгдэж TEDx арга хэмжээг хамтдаа бүтээгээрэй.'
                )}
              </p>
            </div>
            <a
              href="https://docs.google.com/forms/d/e/1FAIpQLSfuZkbisjE0HeH8m-O9R7mwU2li7bBOOlNYU4jC1OtDca1U9Q/viewform?usp=header"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-primary"
              style={{ textAlign: 'center', textDecoration: 'none' }}
            >
              {t('Join the Team', 'Багт нэгдэх')}
            </a>
          </div>
        </div>
      </div>

      {/* Global Footer CTA Banner */}
      <section style={{ padding: '60px 0 20px 0' }}>
        <div
          style={{
            background: 'linear-gradient(135deg, rgba(235, 0, 40, 0.12), rgba(18, 18, 22, 0.8))',
            border: '1px solid rgba(235, 0, 40, 0.3)',
            borderRadius: 20,
            padding: '40px 24px',
            textAlign: 'center',
            backdropFilter: 'blur(12px)',
          }}
        >
          <h2 style={{ fontFamily: 'var(--font-mono)', fontSize: 26, fontWeight: 700, color: '#fff', marginBottom: 12 }}>
            {t('Ready to Leave Your Mark?', 'Өөрийн мөрийг үлдээхэд бэлэн үү?')}
          </h2>
          <p style={{ color: 'var(--text-muted)', maxWidth: 540, margin: '0 auto 28px auto', fontSize: 15, lineHeight: 1.6 }}>
            {t(
              'Whether you have an idea worth spreading or want to help build the event behind the scenes, we want you on board.',
              'Та тайзан дээр илтгэл тавих эсвэл зохион байгуулах багт нэгдэхийг хүссэн ч бид таныг урьж байна.'
            )}
          </p>
        </div>
      </section>
    </main>
  );
}
