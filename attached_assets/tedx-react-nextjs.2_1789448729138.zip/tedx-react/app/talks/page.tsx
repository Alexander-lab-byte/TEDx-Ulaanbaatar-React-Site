'use client';

import { useLanguage } from '@/components/LanguageContext';
import { useReveal } from '@/components/useReveal';

export default function TalksPage() {
  const { t } = useLanguage();
  const reveal = useReveal<HTMLDivElement>();

  return (
    <main>
      <div className="wrap">
        <div ref={reveal.ref} className={`coming-soon-wrapper ${reveal.className}`}>
          <h1 className="aesthetic-text">{t('Coming Soon', 'Тун удахгүй')}</h1>
          <p className="coming-soon-sub">
            {t(
              'The full library of live ideas, student talks, and inspiration will be unlocked right here after the event concludes.',
              'Арга хэмжээ дууссаны дараа сурагчдын болон зочдын бүх илтгэлийн бичлэгүүд энд байрших болно.'
            )}
          </p>
        </div>
      </div>
    </main>
  );
}
