import type { Metadata } from 'next';
import './globals.css';
import { LanguageProvider } from '@/components/LanguageContext';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';

export const metadata: Metadata = {
  title: 'TEDx Ulaanbaatar Empathy School Youth 2026',
  description:
    '14 voices. 100 seats. One day of live student ideas, teacher perspectives, and youth-led innovation in Ulaanbaatar.',
  icons: {
    // logo-black.png is used for the browser tab icon since logo-white.png
    // would be invisible against the light chrome/tab background most
    // browsers use.
    icon: '/logo-black.png',
    apple: '/logo-black.png',
  },
  openGraph: {
    title: 'TEDxUlaanbaatar Empathy School Youth 2026',
    description:
      '14 voices. 100 seats. One day of live student ideas, teacher perspectives, and youth-led innovation in Ulaanbaatar. Apply now!',
    images: ['/social-banner.jpg'],
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'TEDxUlaanbaatar Empathy School Youth 2026',
    description:
      'Join us for a day of youth-led innovation and ideas worth spreading. Apply to speak or join the team today.',
    images: ['/social-banner.jpg'],
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800;900&family=Space+Grotesk:wght@500;700;900&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>
        <LanguageProvider>
          <Navbar />
          {children}
          <Footer />
        </LanguageProvider>
      </body>
    </html>
  );
}
