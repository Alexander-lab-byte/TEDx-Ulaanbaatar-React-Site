'use client';

import Image from 'next/image';
import Countdown from '@/components/Countdown';
import SeatMap from '@/components/SeatMap';
import Speakers from '@/components/Speakers';
import Schedule from '@/components/Schedule';
import ContactSection from '@/components/ContactSection';
import { useLanguage } from '@/components/LanguageContext';
import { useReveal } from '@/components/useReveal';

export default function HomePage() {
  const { t } = useLanguage();
  const heroReveal = useReveal<HTMLDivElement>();
  const aboutReveal = useReveal<HTMLDivElement>();

  return (
    <main>
      {/* ================= HERO ================= */}
      <section className="hero" id="hero">
        <video className="hero-bg" autoPlay muted loop playsInline preload="auto">
          <source src="/davinci_4k___maximum_quality_image_to_video_prompt__genera.mp4" type="video/mp4" />
        </video>

        <div className="hero-overlay"></div>

        <div className="wrap">
          <div ref={heroReveal.ref} className={`hero-content ${heroReveal.className}`}>
            <div className="hero-brand-header">
              <Image src="/logo-white.png" alt="TEDx Ulaanbaatar Empathy School Youth Logo" width={273} height={96} />
            </div>

            <p className="hero-tagline">
              {t(
                '14 voices. 100 seats. One day of live student ideas, teacher perspectives, and youth-led innovation in Ulaanbaatar.',
                '14 дуу хоолой. 100 суудал. Улаанбаатар хотын сурагчдын идэвхи санаачилга, багш нарын үзэл бодол, залуусын инновацийг түгээх нэг өдөр.'
              )}
            </p>

            <Countdown />

            <div className="hero-cta-group">
              <a href="#seats" className="btn-primary">
                {t('Reserve Your Seat', 'Суудлаа захиалах')}
              </a>
              <a href="#speakers" className="btn-secondary">
                {t('Meet The Speakers', 'Илтгэгчидтэй танилцах')}
              </a>
            </div>

            <div className="hero-bottom-meta">
              {t('SATURDAY, OCTOBER 24, 2026', '2026 ОНЫ 10-Р САРЫН 24, БЯМБА ГАРАГ')} <span>•</span>{' '}
              {t('ULAANBAATAR EMPATHY SCHOOL, MONGOLIA', 'УЛААНБААТАР ЭМПАТИ СУРГУУЛЬ, МОНГОЛ')}
            </div>
          </div>
        </div>
      </section>

      {/* ================= ABOUT ================= */}
      <section className="page-section" id="about">
        <div className="wrap">
          <div ref={aboutReveal.ref} className={aboutReveal.className}>
            <div className="section-tag">{t('01 / Event Overview', '01 / Үйл ажиллагааны тухай')}</div>
            <h2 className="section-title">{t('Ideas Worth Spreading', 'Үнэ цэнэтэй санаануудыг түгээх')}</h2>

            <div className="intro-grid">
              <div className="intro-quote">
                {t(
                  '"Empathy isn\'t just something you feel. ',
                  '"Эмпати гэдэг нь зөвхөн мэдрэхүйн асуудал биш. '
                )}
                <span>
                  {t(
                    'It\'s the willingness to stop, listen, and see the world through someone else\'s eyes."',
                    'Энэ нь ойлгон сонсож, ертөнцийг өөр хүний нүдээр харах хүсэл эрмэлзэл юм."'
                  )}
                </span>
              </div>
              <div className="intro-body">
                <p>
                  {t(
                    'We are a team of student organizers at Ulaanbaatar Empathy School creating a platform where youth voices, young innovators, and passionate educators take center stage.',
                    'Бид Улаанбаатар Эмпати Сургуулийн сурагчдын зохион байгууласан баг бөгөөд залуусын дуу хоолой, шинийг санаачлагчид, хүсэл тэмүүлэлтэй сурган хүмүүжүүлэгчдийг тайзан дээр гаргах платформыг бүрдүүлж байна.'
                  )}
                </p>
                <p>
                  {t(
                    'On Saturday, October 24, 2026, our school assembly hall will bring together 100 attendees for a day of live presentations, curated TEDTalks videos, and deep conversations.',
                    '2026 оны 10-р сарын 24-ний Бямба гарагт манай сургуулийн урлаг зааланд 100 оролцогч цугларч, амьд илтгэлүүд, сонгомол TEDTalks бичлэгүүд үзэж, гүн гүнзгий хэлэлцүүлэг өрнүүлэх болно.'
                  )}
                </p>
              </div>
            </div>

            <div className="tedx-compliance-card">
              <h3>{t('What is TEDx?', 'TEDx гэж юу вэ?')}</h3>
              <p>
                {t(
                  'In the spirit of ideas worth spreading, TED has created a program called TEDx. TEDx is a program of local, self-organized events that bring people together to share a TED-like experience. Our event is called ',
                  'Түгээх үнэ цэнэтэй санааг дэмжих зорилгоор TED нь TEDx хэмээх хөтөлбөрийг бий болгосон. TEDx бол орон нутгийн түвшинд бие даан зохион байгуулагддаг, хүмүүсийг нэгтгэн TED-тэй ижил туршлагыг хуваалцах хөтөлбөр юм. Бидний арга хэмжээг '
                )}
                <strong>TEDxUlaanbaatar Empathy School Youth</strong>
                {t(
                  ', where x = independently organized TED event. At our TEDxUlaanbaatar Empathy School Youth event, TEDTalks video and live speakers will combine to spark deep discussion and connection in a small group. The TED Conference provides general guidance for the TEDx program, but individual TEDx events, including ours, are self-organized.',
                  ' гэж нэрлэдэг бөгөөд x = бие даан зохион байгуулагдсан TED арга хэмжээ гэсэн үг юм. Манай арга хэмжээнд TEDTalks бичлэгүүд болон амьд илтгэгчид хосолж, жижиг бүлэгт гүнзгий хэлэлцүүлэг, холбоо үүсгэх болно. TED Конфренц нь TEDx хөтөлбөрт ерөнхий удирдамж өгдөг боловч манайхтай адил хувь хүмүүсийн зохион байгуулж буй TEDx арга хэмжээнүүд нь бие даасан байдаг.'
                )}
              </p>
              <p>
                {t('Learn more about the global ', 'Олон улсын ')}
                <a href="https://www.ted.com/tedx" target="_blank" rel="noopener noreferrer" className="tedx-program-link">
                  {t('TEDx Program →', 'TEDx хөтөлбөрийн →')}
                </a>
                {t('', ' талаар илүү ихийг мэдэж аваарай.')}
              </p>
            </div>

            <div className="venue-info-card">
              <div className="venue-text">
                <h4>{t('Venue: Ulaanbaatar Empathy School Assembly Hall', 'Байршил: Улаанбаатар Эмпати Сургуулийн Урлаг Заал')}</h4>
                <p>
                  {t(
                    'Our event takes place in the main multi-purpose assembly hall of Ulaanbaatar Empathy School, equipped with modern audiovisual systems, a stage, and an interactive horseshoe-style arrangement designed to spark connection between speakers and audience members.',
                    'Манай арга хэмжээ Улаанбаатар Эмпати Сургуулийн орчин үеийн дуу дүрсний системтэй, тайзтай, илтгэгч болон үзэгчдийн хооронд харилцаа үүсгэхэд зориулагдсан тах хэлбэрийн зохион байгуулалттай урлаг зааланд болно.'
                  )}
                </p>
                <div className="venue-meta-badge">
                  {t('📍 Bayanzurkh District, Ulaanbaatar, Mongolia', '📍 Монгол Улс, Улаанбаатар хот, Баянзүрх дүүрэг')}
                </div>
              </div>
              <div>
                <Image
                  src="/ubempathy.jpg"
                  alt="Ulaanbaatar Empathy School Campus"
                  width={520}
                  height={180}
                  style={{ width: '100%', height: 180, objectFit: 'cover', borderRadius: 8, border: '1px solid var(--border-subtle)' }}
                />
              </div>
            </div>
          </div>

          <SeatMap />
        </div>
      </section>

      <Speakers />
      <Schedule />
      <ContactSection />
    </main>
  );
}
