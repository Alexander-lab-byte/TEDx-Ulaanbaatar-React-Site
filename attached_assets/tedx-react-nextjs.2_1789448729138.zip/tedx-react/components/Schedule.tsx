'use client';

import { useState } from 'react';
import TiltCard from './TiltCard';
import { useLanguage } from './LanguageContext';

interface ScheduleRow {
  time: string;
  titleEn: string;
  titleMn: string;
}

interface SessionBlock {
  titleEn: string;
  titleMn: string;
  badge: string;
  rows: ScheduleRow[];
}

const SESSIONS: SessionBlock[] = [
  {
    titleEn: 'Morning Doors & Rehearsal',
    titleMn: 'Өглөөний бүртгэл & Бэлтгэл',
    badge: '08:00 AM – 10:15 AM',
    rows: [
      { time: '08:00 AM – 09:00 AM', titleEn: 'Team & Speaker Preparation', titleMn: 'Баг болон Илтгэгчдийн бэлтгэл' },
      { time: '09:30 AM – 10:15 AM', titleEn: 'Registration & Check-In', titleMn: 'Бүртгэл & Хүлээн авалт' },
    ],
  },
  {
    titleEn: 'SESSION 1 — Local Roots & Discovery',
    titleMn: 'ХЭСЭГ 1 — Орон нутгийн үнэ цэнэ',
    badge: '10:15 AM – 11:21 AM',
    rows: [
      { time: '10:15 AM', titleEn: 'Opening & Welcome', titleMn: 'Нээлтийн үйл ажиллагаа' },
      { time: '10:20 AM – 11:20 AM', titleEn: 'Speaker Block 1 (Coming Soon)', titleMn: 'Илтгэгчид 1 (Тун удахгүй)' },
    ],
  },
  {
    titleEn: 'SESSION 2 — Science, Technology & Systems',
    titleMn: 'ХЭСЭГ 2 — Шинжлэх ухаан, Технологи',
    badge: '12:00 PM – 01:12 PM',
    rows: [{ time: '12:00 PM – 01:12 PM', titleEn: 'Speaker Block 2 (Coming Soon)', titleMn: 'Илтгэгчид 2 (Тун удахгүй)' }],
  },
  {
    titleEn: 'SESSION 3 — Mind, Culture & Society',
    titleMn: 'ХЭСЭГ 3 — Оюун ухаан, Соёл, Нийгэм',
    badge: '02:15 PM – 03:18 PM',
    rows: [{ time: '02:15 PM – 03:18 PM', titleEn: 'Speaker Block 3 (Coming Soon)', titleMn: 'Илтгэгчид 3 (Тун удахгүй)' }],
  },
];

export default function Schedule() {
  const { t } = useLanguage();
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section className="page-section" id="schedule">
      <div className="wrap reveal">
        <div className="section-tag">{t('03 / Timetable', '03 / Цагийн хуваарь')}</div>
        <h2 className="section-title">{t('Event Schedule (Coming Soon)', 'Арга хэмжээний хөтөлбөр (Тун удахгүй)')}</h2>
        <p style={{ color: 'var(--text-muted)', marginBottom: 24 }}>
          {t('Click on a session below to view details.', 'Доорх хэсэгт дарж дэлгэрэнгүй хуваарийг харна уу.')}
        </p>

        <div className="schedule-container">
          {SESSIONS.map((session, idx) => {
            const isOpen = openIndex === idx;
            return (
              <TiltCard key={idx} className="session-block">
                <div
                  className={`session-header${isOpen ? ' active-header' : ''}`}
                  onClick={() => setOpenIndex(isOpen ? null : idx)}
                >
                  <div>
                    <h3>{t(session.titleEn, session.titleMn)}</h3>
                    <span className="session-badge">{session.badge}</span>
                  </div>
                  <div className="toggle-icon">{isOpen ? '−' : '+'}</div>
                </div>

                <div className="session-items" style={{ display: isOpen ? 'block' : 'none' }}>
                  {session.rows.map((row, rIdx) => (
                    <div className="schedule-row" key={rIdx}>
                      <div className="time-col">{row.time}</div>
                      <div className="info-col">
                        <div className="event-title">{t(row.titleEn, row.titleMn)}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </TiltCard>
            );
          })}
        </div>
      </div>
    </section>
  );
}
