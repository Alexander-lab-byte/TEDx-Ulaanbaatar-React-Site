'use client';

import { useMemo, useState } from 'react';
import { useLanguage } from './LanguageContext';

const TOTAL_SEATS = 100;
// Empty set below = all 100 seats available. Add seat numbers here to mark them taken.
const TAKEN_SEATS = new Set<number>([]);

export default function SeatMap() {
  const { t } = useLanguage();
  const [selectedSeat, setSelectedSeat] = useState<number | null>(null);
  const [seatSize, setSeatSize] = useState(22);

  const remaining = TOTAL_SEATS - TAKEN_SEATS.size;

  const seats = useMemo(() => {
    const left: number[] = [];
    const center: number[] = [];
    const right: number[] = [];
    for (let i = 1; i <= TOTAL_SEATS; i++) {
      if (i <= 30) left.push(i);
      else if (i <= 70) center.push(i);
      else right.push(i);
    }
    return { left, center, right };
  }, []);

  const handleSelect = (seatNum: number) => {
    if (selectedSeat === seatNum) {
      setSelectedSeat(null);
      return;
    }
    setSelectedSeat(seatNum);
    alert(
      t(
        `You've selected Seat #${seatNum}! Contact us or send a direct message on Instagram to complete your registration.`,
        `Та #${seatNum} суудлыг сонголоо! Бүртгэлээ дуусгахын тулд бидэнтэй холбогдох эсвэл Инстаграмаар шууд бичнэ үү.`
      )
    );
  };

  const renderSeat = (num: number) => {
    const taken = TAKEN_SEATS.has(num);
    const selected = selectedSeat === num;
    const classes = ['seat'];
    if (taken) classes.push('occupied');
    else if (selected) classes.push('selected');

    return (
      <div
        key={num}
        className={classes.join(' ')}
        title={taken ? `Seat #${num} is taken` : `Seat #${num} ${selected ? 'selected' : 'available'}`}
        onClick={taken ? undefined : () => handleSelect(num)}
      >
        {num}
      </div>
    );
  };

  return (
    <div
      className="seat-section-wrapper reveal"
      id="seats"
      style={{ '--seat-size': `${seatSize}px` } as React.CSSProperties}
    >
      <div className="seat-header">
        <div>
          <h3 style={{ fontSize: 19, fontWeight: 800 }}>
            {t('Hall Seat Availability', 'Танхимын суудлын мэдээлэл')}
          </h3>
          <p style={{ fontSize: 12.5, color: 'var(--text-muted)', marginTop: 2 }}>
            {t('Tap any available seat to reserve your spot.', 'Сул суудал дээр дарж суудлаа захиална уу.')}
          </p>
        </div>

        <div className="seat-counter-badge">
          <div className="num">{remaining}</div>
          <div style={{ textAlign: 'left' }}>
            <div style={{ fontSize: 10, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--text-white)' }}>
              {t('Seats Remaining', 'Үлдсэн суудал')}
            </div>
            <div style={{ fontSize: 10.5, color: 'var(--text-muted)' }}>{t('out of 100 capacity', 'Нийт 100 суудлаас')}</div>
          </div>
        </div>
      </div>

      <div className="seat-controls-bar">
        <label htmlFor="seatSlider">{t('View Zoom:', 'Томруулах:')}</label>
        <input
          type="range"
          className="seat-slider"
          id="seatSlider"
          min={15}
          max={32}
          value={seatSize}
          onChange={(e) => setSeatSize(Math.max(14, Math.min(32, parseInt(e.target.value, 10))))}
        />
      </div>

      <div className="stage-wrapper">
        <div className="screen-bar"></div>
        <div className="screen-label">{t('MAIN PODIUM / STAGE', 'ГОЛ ТАЙЗ')}</div>
      </div>

      <div className="theater-3d-stage">
        <div className="theater-layout">
          <div className="wing-block block-left">
            <div className="wing-title">{t('Left Wing (30)', 'Зүүн жигүүр (30)')}</div>
            <div className="seat-grid-left">{seats.left.map(renderSeat)}</div>
          </div>

          <div className="wing-block block-center">
            <div className="wing-title">{t('Center Main (40)', 'Төв хэсэг (40)')}</div>
            <div className="seat-grid-center">{seats.center.map(renderSeat)}</div>
          </div>

          <div className="wing-block block-right">
            <div className="wing-title">{t('Right Wing (30)', 'Баруун жигүүр (30)')}</div>
            <div className="seat-grid-right">{seats.right.map(renderSeat)}</div>
          </div>
        </div>
      </div>

      <div className="seat-legend">
        <div className="legend-item">
          <div className="legend-dot" style={{ background: '#27272A' }}></div> <span>{t('Available', 'Боломжтой')}</span>
        </div>
        <div className="legend-item">
          <div className="legend-dot" style={{ background: 'var(--ted-red)' }}></div> <span>{t('Selected', 'Сонгосон')}</span>
        </div>
        <div className="legend-item">
          <div className="legend-dot" style={{ background: 'rgba(255, 255, 255, 0.08)' }}></div> <span>{t('Taken', 'Захиалагдсан')}</span>
        </div>
      </div>
    </div>
  );
}
