'use client';

import { FormEvent, useState } from 'react';
import TiltCard from './TiltCard';
import { useLanguage } from './LanguageContext';

export default function ContactSection() {
  const { t } = useLanguage();
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSubmitted(true);
    e.currentTarget.reset();
    setTimeout(() => setSubmitted(false), 4000);
  };

  return (
    <section className="page-section" id="contact">
      <div className="wrap reveal">
        <div className="section-tag">{t('04 / Get In Touch', '04 / Холбоо барих')}</div>
        <h2 className="section-title">{t('Reach Out to Our Team', 'Бидэнтэй холбогдох')}</h2>

        <div className="contact-grid">
          <TiltCard className="contact-form-card">
            <h3 className="form-heading">{t('Send a Message', 'Зурвас илгээх')}</h3>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label htmlFor="fullName">{t('Your Name', 'Таны нэр')}</label>
                <input
                  type="text"
                  id="fullName"
                  required
                  placeholder={t('e.g. Anujin Batbayar', 'Жнь: Анужин Батбаяр')}
                />
              </div>

              <div className="form-group">
                <label htmlFor="emailAddress">{t('Email Address', 'И-мэйл хаяг')}</label>
                <input
                  type="email"
                  id="emailAddress"
                  required
                  placeholder={t('e.g. name@example.com', 'Жнь: name@example.com')}
                />
              </div>

              <div className="form-group">
                <label htmlFor="message">{t('Message / Question', 'Таны зурвас')}</label>
                <textarea
                  id="message"
                  rows={4}
                  required
                  placeholder={t('How can we help you?', 'Бид танд хэрхэн туслах вэ?')}
                ></textarea>
              </div>

              <button type="submit" className="btn-primary" style={{ width: '100%' }}>
                {t('Send Message', 'Илгээх')}
              </button>

              {submitted && (
                <div
                  style={{
                    display: 'block',
                    marginTop: 16,
                    padding: 12,
                    background: 'rgba(235,0,40,0.2)',
                    border: '1px solid var(--ted-red)',
                    borderRadius: 6,
                    fontSize: 13,
                    textAlign: 'center',
                  }}
                >
                  {t("Message received! We'll reply shortly.", 'Зурвас хүлээн авлаа! Бид удахгүй хариу өгөх болно.')}
                </div>
              )}
            </form>
          </TiltCard>

          <TiltCard className="contact-info-card">
            <h3 className="form-heading">{t('Organizers (Hover for Bio)', 'Зохион байгуулагчид')}</h3>

            <div className="organizer-hover-card">
              <div className="org-front">
                <span style={{ fontWeight: 700, fontSize: 14.5 }}>Munkhtushig</span>
                <span className="role-badge">{t('ORGANIZER', 'ЗОХИОН БАЙГУУЛАГЧ')}</span>
              </div>
              <div className="org-back">
                {t(
                  '🧬 Student who loves to learn more. Highly disciplined and ambitious, dedicated to bringing youth ideas to life!',
                  '🧬 Биологийн чиглэлээр суралцдаг. Маш сахилга баттай, амбицтай бөгөөд залуусын санааг бодит болгох эрмэлзэлтэй!'
                )}
              </div>
            </div>

            <div className="organizer-hover-card">
              <div className="org-front">
                <span style={{ fontWeight: 700, fontSize: 14.5 }}>Munkherdene</span>
                <span className="role-badge">{t('CO-ORGANIZER', 'ХАМТРАН ЗОХИОН БАЙГУУЛАГЧ')}</span>
              </div>
              <div className="org-back">
                {t(
                  '🚀 Tech director & event coordinator. Dedicated to building smooth, impactful youth-led events!',
                  '🚀 Технологийн найруулагч, арга хэмжээ зохицуулагч. Залууст чиглэсэн нөлөөлөхүйц арга хэмжээ зохион байгуулах хүсэлтэй!'
                )}
              </div>
            </div>

            <div style={{ marginTop: 20 }}>
              <p style={{ fontSize: 13.5, color: 'var(--text-muted)', marginBottom: 6 }}>
                <strong>{t('Email:', 'И-мэйл:')}</strong>{' '}
                <a href="mailto:sergelenmunkhtushig@gmail.com" style={{ color: 'var(--ted-red)' }}>
                  sergelenmunkhtushig@gmail.com
                </a>
              </p>
              <p style={{ fontSize: 13.5, color: 'var(--text-muted)', marginBottom: 6 }}>
                <strong>{t('Instagram:', 'Инстаграм:')}</strong>{' '}
                <a
                  href="https://www.instagram.com/tedxempathyschool_youth/"
                  target="_blank"
                  rel="noopener noreferrer"
                  style={{ color: 'var(--ted-red)' }}
                >
                  @tedxempathyschool_youth
                </a>
              </p>
              <p style={{ fontSize: 13.5, color: 'var(--text-muted)' }}>
                <strong>{t('Location:', 'Байршил:')}</strong>{' '}
                {t('Ulaanbaatar Empathy School, Ulaanbaatar, Mongolia', 'Улаанбаатар Эмпати Сургууль, Улаанбаатар хот, Монгол Улс')}
              </p>
            </div>

            <div className="map-container">
              <iframe
                src="https://maps.google.com/maps?q=Ulaanbaatar%20Empathy%20School&t=&z=15&ie=UTF8&iwloc=&output=embed"
                allowFullScreen
                loading="lazy"
                title="Location Map"
                referrerPolicy="no-referrer-when-downgrade"
              ></iframe>
            </div>
          </TiltCard>
        </div>
      </div>
    </section>
  );
}
