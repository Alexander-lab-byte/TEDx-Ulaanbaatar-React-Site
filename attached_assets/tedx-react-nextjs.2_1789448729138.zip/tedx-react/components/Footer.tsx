'use client';

import Image from 'next/image';
import { useLanguage } from './LanguageContext';

export default function Footer() {
  const { t } = useLanguage();

  return (
    <footer>
      <div className="wrap">
        <div className="brand-logo" style={{ marginBottom: 16 }}>
          <Image src="/logo-white.png" alt="TEDx Logo" width={273} height={96} />
        </div>
        <div className="footer-legal">
          <div>
            {t(
              'This independent TEDx event is operated under license from TED.',
              'Энэхүү бие даасан TEDx арга хэмжээ нь TED-ийн тусгай зөвшөөрлийн дагуу зохион байгуулагдаж байна.'
            )}
          </div>
          <div>
            <strong>TEDxUlaanbaatar Empathy School Youth</strong> © 2026
          </div>
        </div>
      </div>
    </footer>
  );
}
