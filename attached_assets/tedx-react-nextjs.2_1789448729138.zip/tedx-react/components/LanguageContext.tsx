'use client';

import { createContext, useContext, useState, ReactNode } from 'react';

type Lang = 'EN' | 'MN';

interface LanguageContextType {
  lang: Lang;
  toggleLanguage: () => void;
  /** Returns the English or Mongolian string depending on the active language. */
  t: (en: string, mn: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLang] = useState<Lang>('EN');

  const toggleLanguage = () => setLang((prev) => (prev === 'EN' ? 'MN' : 'EN'));
  const t = (en: string, mn: string) => (lang === 'EN' ? en : mn);

  return (
    <LanguageContext.Provider value={{ lang, toggleLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error('useLanguage must be used within a LanguageProvider');
  return ctx;
}
