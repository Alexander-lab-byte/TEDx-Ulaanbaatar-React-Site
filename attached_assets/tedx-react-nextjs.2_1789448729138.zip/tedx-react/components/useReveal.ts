'use client';

import { useEffect, useRef, useState } from 'react';

/**
 * Replaces the old vanilla-JS IntersectionObserver reveal script.
 * Attach the returned ref to any element and spread `className`
 * to get the same fade/slide-up-on-scroll behavior as `.reveal` / `.reveal.active`.
 */
export function useReveal<T extends HTMLElement = HTMLDivElement>() {
  const ref = useRef<T | null>(null);
  const [active, setActive] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    if (!('IntersectionObserver' in window)) {
      setActive(true);
      return;
    }

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActive(true);
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.1 }
    );

    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return { ref, className: `reveal${active ? ' active' : ''}` };
}
