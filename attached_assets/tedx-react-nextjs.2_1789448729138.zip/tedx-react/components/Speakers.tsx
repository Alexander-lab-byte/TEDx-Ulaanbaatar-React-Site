'use client';

import { useRef, useState } from 'react';
import TiltCard from './TiltCard';
import { useLanguage } from './LanguageContext';

interface SpeakerEntry {
  type: string;
  desc: string;
}

const SPEAKERS: SpeakerEntry[] = [
  { type: 'Local Teacher Speaker', desc: '12-minute talk exploring interactive learning and critical student thinking.' },
  { type: 'Student Speaker', desc: '6-minute talk on balancing modern digital life with high school growth.' },
  { type: 'External Speaker', desc: '15-minute talk on community resilience and local youth initiatives.' },
  { type: 'Student Speaker', desc: '6-minute talk on creative digital storytelling in modern Mongolia.' },
  { type: 'Local Teacher Speaker', desc: '12-minute talk bridging classroom curiosity with practical life skills.' },
  { type: 'Student Speaker', desc: '5-minute talk on peer empathy, mental strength, and supporting friends.' },
  { type: 'External Speaker', desc: '15-minute talk on tech ethics and building responsible AI tools.' },
  { type: 'Student Speaker', desc: '6-minute talk on youth action for urban sustainability.' },
  { type: 'Local Teacher Speaker', desc: '12-minute talk on encouraging curiosity over rote memorization.' },
  { type: 'Student Speaker', desc: '6-minute talk on how high school volunteering transforms communities.' },
  { type: 'External Speaker', desc: '15-minute talk connecting Mongolian heritage with Gen-Z innovation.' },
  { type: 'Local Teacher Speaker', desc: '12-minute talk mentoring young researchers for regional impact.' },
  { type: 'External Speaker', desc: '15-minute talk on taking bold entrepreneurial steps in youth.' },
  { type: 'Student Speaker', desc: '6-minute talk on why embracing creative risk shapes the future.' },
];

export default function Speakers() {
  const { t } = useLanguage();
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const [activeSpeaker, setActiveSpeaker] = useState<{ num: string; type: string; desc: string } | null>(null);

  const scrollBy = (offset: number) => {
    scrollRef.current?.scrollBy({ left: offset, behavior: 'smooth' });
  };

  return (
    <section className="page-section" id="speakers">
      <div className="wrap reveal">
        <div className="section-tag">{t('02 / On Stage', '02 / Тайзнаа')}</div>
        <h2 className="section-title" style={{ marginBottom: 16 }}>
          {t('14 Live Speakers', '14 Илтгэгч')}
        </h2>

        <div className="speakers-header-wrapper">
          <div className="speaker-category-pills">
            <div className="cat-pill">
              <span>6</span> <span>{t('Student Speakers', 'Сурагч илтгэгч')}</span>
            </div>
            <div className="cat-pill">
              <span>4</span> <span>{t('Local Teachers', 'Багш нар')}</span>
            </div>
            <div className="cat-pill">
              <span>4</span> <span>{t('External Speakers', 'Зочин илтгэгч')}</span>
            </div>
          </div>

          <div className="scroll-controls">
            <button className="scroll-btn" onClick={() => scrollBy(-260)} aria-label="Scroll left">
              ←
            </button>
            <button className="scroll-btn" onClick={() => scrollBy(260)} aria-label="Scroll right">
              →
            </button>
          </div>
        </div>

        <div className="speakers-scroll-container" ref={scrollRef}>
          {SPEAKERS.map((sp, idx) => {
            const num = idx + 1 < 10 ? `0${idx + 1}` : `${idx + 1}`;
            return (
              <TiltCard
                key={num}
                className="speaker-card"
                onClick={() => setActiveSpeaker({ num, type: sp.type, desc: sp.desc })}
              >
                <div className="speaker-avatar">?</div>
                <div className="speaker-tag-label">{sp.type}</div>
                <div className="speaker-name">Speaker #{num}</div>
                <div className="speaker-card-cta">{t('Tap for talk overview →', 'Дэлгэрэнгүй үзэх →')}</div>
              </TiltCard>
            );
          })}
        </div>
      </div>

      {activeSpeaker && (
        <div
          className="modal-overlay active"
          onClick={(e) => {
            if (e.target === e.currentTarget) setActiveSpeaker(null);
          }}
        >
          <div className="modal-card">
            <button className="modal-close" onClick={() => setActiveSpeaker(null)} aria-label="Close modal">
              ×
            </button>
            <div className="speaker-tag-label">{activeSpeaker.type}</div>
            <div style={{ fontFamily: 'var(--font-mono)', color: 'var(--ted-red)', fontSize: 12, marginTop: 4 }}>
              Speaker #{activeSpeaker.num}
            </div>
            <h3 style={{ fontSize: 20, fontWeight: 800, margin: '8px 0' }}>Featured Speaker {activeSpeaker.num}</h3>
            <p style={{ color: 'var(--text-muted)', fontSize: 13.5, marginBottom: 18, lineHeight: 1.5 }}>
              {activeSpeaker.desc}
            </p>
            <button className="btn-primary" onClick={() => setActiveSpeaker(null)} style={{ width: '100%' }}>
              {t('Close', 'Хаах')}
            </button>
          </div>
        </div>
      )}
    </section>
  );
}
