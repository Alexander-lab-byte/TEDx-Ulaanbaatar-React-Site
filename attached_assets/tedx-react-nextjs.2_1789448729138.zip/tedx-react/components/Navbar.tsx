'use client';

import Link from 'next/link';
import Image from 'next/image';
import { useState } from 'react';
import { usePathname } from 'next/navigation';
import { useLanguage } from './LanguageContext';

const NAV_LINKS: { href: string; en: string; mn: string; accent?: boolean }[] = [
  { href: '/#about', en: 'About', mn: 'Бидний тухай' },
  { href: '/#seats', en: 'Seats', mn: 'Суудал' },
  { href: '/#speakers', en: 'Speakers', mn: 'Илтгэгчид' },
  { href: '/talks', en: 'Talks', mn: 'Илтгэлүүд' },
  { href: '/team', en: 'Team', mn: 'Баг' },
  { href: '/apply', en: 'Apply', mn: 'Бүртгүүлэх', accent: true },
  { href: '/#contact', en: 'Contact', mn: 'Холбоо барих' },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();
  const { lang, toggleLanguage, t } = useLanguage();

  const close = () => setOpen(false);

  return (
    <header className="nav">
      <div className="wrap nav-inner">
        <Link
          href="/"
          className="brand-logo-container"
          title="TEDx Ulaanbaatar Empathy School Youth"
          onClick={close}
        >
          <Image
            src="/logo-white.png"
            alt="TEDx Logo"
            width={273}
            height={96}
            className="brand-logo-img"
            priority
          />
        </Link>

        <button
          className={`mobile-menu-btn${open ? ' active' : ''}`}
          id="mobileMenuBtn"
          aria-label="Toggle Navigation Menu"
          onClick={() => setOpen((o) => !o)}
        >
          <span></span>
          <span></span>
          <span></span>
        </button>

        <nav className={`nav-links${open ? ' nav-active' : ''}`} id="navLinks">
          {NAV_LINKS.map((link) => {
            const basePath = link.href.split('#')[0] || '/';
            const isActive = basePath !== '/' && pathname === basePath;
            return (
              <Link
                key={link.href}
                href={link.href}
                onClick={close}
                className={isActive ? 'active' : ''}
                style={link.accent ? { color: 'var(--ted-red)', fontWeight: 700 } : undefined}
              >
                {t(link.en, link.mn)}
              </Link>
            );
          })}

          <div className="nav-actions">
            <button className="lang-toggle-btn" onClick={toggleLanguage}>
              <span className={lang === 'EN' ? 'lang-en active' : 'lang-en'} style={{ color: lang === 'EN' ? 'var(--ted-red)' : undefined }}>
                EN
              </span>{' '}
              /{' '}
              <span className={lang === 'MN' ? 'lang-mn active' : 'lang-mn'} style={{ color: lang === 'MN' ? 'var(--ted-red)' : undefined }}>
                MN
              </span>
            </button>
            <Link
              href="/#seats"
              className="btn-primary"
              style={{ padding: '8px 16px', fontSize: 11 }}
              onClick={close}
            >
              {t('Reserve Seat', 'Суудал захиалах')}
            </Link>
          </div>
        </nav>
      </div>
    </header>
  );
}
