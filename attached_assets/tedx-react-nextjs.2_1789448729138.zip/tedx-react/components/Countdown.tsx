'use client';

import { useEffect, useState } from 'react';
import { useLanguage } from './LanguageContext';

const EVENT_TARGET = new Date('October 24, 2026 08:00:00').getTime();

function pad(n: number) {
  return n < 10 ? `0${n}` : `${n}`;
}

export default function Countdown() {
  const { t } = useLanguage();
  const [timeLeft, setTimeLeft] = useState<{ days: number; hours: number; mins: number; secs: number } | null>(
    null
  );
  const [isLive, setIsLive] = useState(false);

  useEffect(() => {
    const tick = () => {
      const diff = EVENT_TARGET - Date.now();
      if (diff <= 0) {
        setIsLive(true);
        return;
      }
      setTimeLeft({
        days: Math.floor(diff / (1000 * 60 * 60 * 24)),
        hours: Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
        mins: Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60)),
        secs: Math.floor((diff % (1000 * 60)) / 1000),
      });
    };
    tick();
    const interval = setInterval(tick, 1000);
    return () => clearInterval(interval);
  }, []);

  if (isLive) {
    return (
      <div className="hero-countdown" id="eventCountdown">
        <div style={{ color: 'var(--ted-red)', fontWeight: 800, fontSize: 18 }}>
          {t('EVENT IS LIVE TODAY!', 'АРГА ХЭМЖЭЭ ӨНӨӨДӨР БОЛЖ БАЙНА!')}
        </div>
      </div>
    );
  }

  return (
    <div className="hero-countdown" id="eventCountdown">
      <div className="time-block">
        <span>{timeLeft ? pad(timeLeft.days) : '00'}</span>
        <label>{t('Days', 'Өдөр')}</label>
      </div>
      <div className="time-block">
        <span>{timeLeft ? pad(timeLeft.hours) : '00'}</span>
        <label>{t('Hours', 'Цаг')}</label>
      </div>
      <div className="time-block">
        <span>{timeLeft ? pad(timeLeft.mins) : '00'}</span>
        <label>{t('Mins', 'Минут')}</label>
      </div>
      <div className="time-block">
        <span>{timeLeft ? pad(timeLeft.secs) : '00'}</span>
        <label>{t('Secs', 'Секунд')}</label>
      </div>
    </div>
  );
}
