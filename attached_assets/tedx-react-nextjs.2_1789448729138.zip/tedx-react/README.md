# TEDx Ulaanbaatar Empathy School Youth — Next.js conversion

This is your original static HTML/CSS/JS site (index.html, apply.html,
library.html, team.html) converted into a Next.js 16 App Router project,
matching the file structure shown in your screenshot.

## What changed
- **Pages**: `app/page.tsx` (home), `app/apply/page.tsx`, `app/talks/page.tsx`
  (formerly library.html), `app/team/page.tsx`.
- **Shared layout**: `app/layout.tsx` renders a single `Navbar` and `Footer`
  (from `components/`) around every page, instead of duplicating the header/
  footer markup + scripts in every HTML file.
- **Language toggle**: replaced the DOM-querying `toggleLanguage()` script
  with a React Context (`components/LanguageContext.tsx`) and a `t(en, mn)`
  helper used throughout.
- **Interactivity → hooks/components**:
  - `components/useReveal.ts` — scroll reveal (`IntersectionObserver`)
  - `components/TiltCard.tsx` — the mousemove 3D tilt effect
  - `components/Countdown.tsx` — the event countdown timer
  - `components/SeatMap.tsx` — the 100-seat picker + zoom slider
  - `components/Speakers.tsx` — speaker carousel + modal
  - `components/Schedule.tsx` — the accordion schedule
  - `components/ContactSection.tsx` — contact form + organizer cards + map
- **Styles**: all of `style.css`, `team.css`, `library.css`, plus the
  page-specific `<style>` blocks that lived inside `apply.html`, `team.html`,
  and `library.html`, are merged into `app/globals.css` so nothing was lost.

## Before you run it
1. Copy this into your existing `tedx-app/` project (or use it as-is), so
   the folder layout matches: `app/`, `app/apply/`, `app/talks/`,
   `app/team/`, `components/`.
2. Copy your real image/video assets into `public/` — see
   `public/README-ASSETS.txt` for the exact filenames the code expects
   (`logo-white.png`, `ubempathy.jpg`, the hero video, `social-banner.jpg`).
   These weren't part of your upload so they're not included here.
3. `npm install`
4. `npm run dev` and open http://localhost:3000

This has already been verified with `next build` — it compiles and
type-checks cleanly with no errors.
