Real assets now included in this folder:
  logo-white.png    — used in the navbar/footer/hero (dark backgrounds)
  logo-black.png    — used as the browser tab favicon (light background)
  ubempathy.jpg     — venue photo in the About section
  davinci_4k___maximum_quality_image_to_video_prompt__genera.mp4 — hero background video

Also included, not currently wired into any page:
  kling_20260805_VIDEO_shot_1_5s__3222_0.mp4 — alternate short video clip
  08_TEDx_Logo_Long-Modifier.eps — vector logo (print/design use; browsers
    can't render .eps directly, so it's kept here for reference only, not
    referenced in the code)

social-banner.jpg (Open Graph / Twitter preview image) is still not
included — add it here if you want link previews to show an image.
